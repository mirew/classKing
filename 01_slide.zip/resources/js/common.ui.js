/*
 파일명:		common.ui.js
 설  명:		slider
 작성자:		glim
 최초작성일:	  2020/04/20
 최종수정일:
*/

(function ($) {
	$.fn.mySlider = function (options) {
		this.each(function () {
			var selector = $(this),
				selectorWidth = selector.width(),
				sliderWrapper = $(this).find('.slider-wrapper'),
				sliderItems = sliderWrapper.find('.slider-item'),
				slideBtn = selector.find('.slider-arrow .slider-btn'),
				slidePagination = selector.find('.slider-pagination'),
				totalNum = sliderWrapper.find('.slider-item').length,
				totalWidth = 0,
				currentIdx = 0,
				oldMoveVal = 0,
				moveVal = 0,
				resizeMove = 0,
				settings = $.extend({ // option
					speed: 300,
					perView: 1,
					spaceBetween: 0,
					mode: 'horizontal',
				}, options);

			function init() {
				setOption();

				selector.find('.slider-arrow .slider-btn.prev').attr('disabled', true); // 이전버튼 disabled 처리
				if (settings.mode == 'horizontal') {
					if (selectorWidth > totalWidth) { // 다음 슬라이드 처리할게 없는 경우
						selector.find('.slider-arrow .slider-btn.next').attr('disabled', true); // 다음버튼 disabled 처리
					}
				}
			}

			init();

			// resize시 slide width, 이동할 x값 계산
			/*$(window).on('resize' ,function(){
				if($(window).width() == selectorWidth){
					setSlideWidth();

					if(moveVal !== 0){
						resizeMove = selectorWidth - selectorWidth;
						moveVal = oldMoveVal - resizeMove;

						sliderWrapper.css({
							"transform": 'translateX(' + -moveVal + 'px)',
							"transition-duration": 0 + 'ms',
						});
					};
					console.log(currentIdx)
				};
			});*/

			// 슬라이드 옵션 적용
			function setOption() {
				// slide item space setting
				if (settings.spaceBetween !== 0) sliderItems.css('margin-right', settings.spaceBetween + 'px');

				// slide item width setting
				setSlideWidth();
				// console.log(totalWidth);

				// slide item pagination setting
				console.log(totalWidth % selectorWidth)
				if ((totalWidth % selectorWidth) !== 0) { // slide width 100% 아닌경우 페이징 갯수 체크
					var tailWidth = 0;

					for (var i = totalNum - 1; i > 0; i--) {
						if ((totalWidth % selectorWidth) > tailWidth) {
							tailWidth += sliderItems.eq(i).data('width');
							totalNum = i + 2;
						}
					}   
				}

				if (settings.pagination == 'bullet') {
					for (var i = 0; i < totalNum; i++) {
						slidePagination.append("<span class='pagination-bullet'></span>")
					}

					slidePagination.find('.pagination-bullet').eq(currentIdx).addClass('is-active');

				} else if (settings.pagination == 'fraction') {
					slidePagination.append("<span class='pagination-current'>" + (currentIdx + 1) + "</span>")
					slidePagination.append("<span class='pagination-total'>" + totalNum + "</span>")
				}
			}

			// 슬라이드 전체, 개별 넓이 구하기
			function setSlideWidth() {
				if (settings.perView !== 'auto') sliderItems.css('width', selectorWidth / settings.perView);

				if (settings.mode == 'horizontal') {
					sliderItems.each(function () { // slide item width 값 저장
						var itemWidth = $(this).outerWidth(true);
						$(this).data('width', itemWidth);
						totalWidth += itemWidth;
					});
				}
			}

			// 마우스 드래그로 prev, next 체크
			function setDragMove() {
				var clicking = false,
					dragDirection = false;

				selector.on('mousedown', function (event) {
					clicking = true;
					dragDirection = event.offsetX;
				});

				selector.on('mouseup', function (event) {
					clicking = false;

					if (event.offsetX - dragDirection > 100) {
						console.log("right");
					}
					if (event.offsetX - dragDirection < -100) {
						console.log("left");
					}
				});

				/*selector.on('mousemove', function(event){
					if(clicking == false) return;

					console.log("move");

				});*/
			}

			// prev, next 체크하여 슬라이드 이동값 계산
			slideBtn.on('click', function () {
				oldMoveVal = moveVal; // oldMoveVal, moveVal 초기화
				if ($(this).siblings().prop('disabled', true)) {
					$(this).siblings().prop('disabled', false);
				}

				if ($(this).hasClass('next')) { // next 버튼 클릭
					currentIdx += 1;
					currentIdx >= totalNum ? $(this).prop('disabled', true) : $(this).prop('disabled', false); // 더이상 증가할 인덱스 없으면 button disabled 처리

					if (sliderItems.eq(totalNum - 1).outerWidth(true) < totalWidth - (selectorWidth + moveVal)) {
						moveVal = oldMoveVal + sliderItems.eq(currentIdx - 1).data('width'); // 현재 이동한 X값 + 다음 슬라이드 width값
					} else { // 마지막 슬라이드가 화면에 일부 노출되는 경우 이동할 X값 계산
						moveVal = oldMoveVal + (totalWidth - (selectorWidth + moveVal)); // 현재 이동한 X값 + 노출된 슬라이드 값 제외한 나머지
						$(this).prop('disabled', true); // next 버튼 비활성화
					}

				} else { // prev 버튼 클릭
					currentIdx -= 1;
					currentIdx <= 0 ? $(this).prop('disabled', true) : $(this).prop('disabled', false); // 더이상 감소할 인덱스 없으면 button disabled 처리
					// console.log(currentIdx)

					if (settings.perView > 1 || settings.perView == 'auto') { // slide width 100% 아닌경우
						if (moveVal + selectorWidth == totalWidth) { // 마지막 슬라이드에서 이전버튼 클릭한경우
							var tailWidth = 0;
							for (var i = currentIdx; i <= totalNum - 1; i++) {
								tailWidth += sliderItems.eq(i).data('width');
								console.log(i)
								console.log(tailWidth)
							}
							;

							moveVal = oldMoveVal - (tailWidth - selectorWidth);
						} else {
							moveVal = oldMoveVal - sliderItems.eq(currentIdx).data('width'); // 현재 이동한 X값 - 다음 슬라이드 width값
						}
					} else {
						moveVal = oldMoveVal - sliderItems.eq(currentIdx).data('width'); // 현재 이동한 X값 - 다음 슬라이드 width값
					}
				}

				oldMoveVal = moveVal;

				if (settings.pagination == 'bullet') {
					slidePagination.find('.pagination-bullet').removeClass('is-active');
					slidePagination.find('.pagination-bullet').eq(currentIdx).addClass('is-active');
				} else if (settings.pagination == 'fraction') {
					slidePagination.find('.pagination-current').text(currentIdx + 1);
				}

				sliderWrapper.css({
					"transform": 'translateX(' + -moveVal + 'px)',
					"transition-duration": settings.speed + 'ms',
				});
			});

			// pagination click
			slidePagination.find('.pagination-bullet').on('click', function () {
				moveVal = 0; // moveVal 초기화
				currentIdx = $(this).index(); // 현재 인덱스를 클릭한 불릿 인덱스로 변경

				if (currentIdx <= 0) { // prev, next 버튼 비활성화
					selector.find('.slider-arrow .slider-btn.next').prop('disabled', false);
					selector.find('.slider-arrow .slider-btn.prev').prop('disabled', true);
				} else if (currentIdx >= (totalNum - 1)) {
					selector.find('.slider-arrow .slider-btn.prev').prop('disabled', false);
					selector.find('.slider-arrow .slider-btn.next').prop('disabled', true);
				} else {
					slideBtn.prop('disabled', false);
				}

				if (currentIdx == totalNum - 1) { // 마지막 슬라이드 체크
					for (var i = 0; i < totalNum - 2; i++) { // 마지막 이전 슬라이드 moveVal 계산
						moveVal += sliderItems.eq(i).data('width');
					}

					if (sliderItems.eq(totalNum).outerWidth(true) < totalWidth - (selectorWidth + moveVal)) {
						moveVal += sliderItems.eq(totalNum - 1).data('width');
					} else { // 마지막 슬라이드가 화면에 일부 노출되는 경우 이동할 X값 계산
						moveVal = moveVal + (totalWidth - (selectorWidth + moveVal)); // 현재 이동한 X값 + 노출된 슬라이드 값 제외한 나머지
					}
				} else {
					for (var i = 0; i < currentIdx; i++) { // 이동할 moveVal 계산
						moveVal += sliderItems.eq(i).data('width');
					}
				}

				oldMoveVal = moveVal;

				slidePagination.find('.pagination-bullet').removeClass('is-active');
				slidePagination.find('.pagination-bullet').eq(currentIdx).addClass('is-active');

				sliderWrapper.css({
					"transform": 'translateX(' + -moveVal + 'px)',
					"transition-duration": settings.speed + 'ms',
				});
			});
		});

		return this;
	};
}(jQuery));


